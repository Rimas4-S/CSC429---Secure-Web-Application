from flask import Flask, render_template, request, redirect, url_for, session, flash, g
from werkzeug.security import generate_password_hash, check_password_hash
import sqlite3

app = Flask(__name__)
app.secret_key = 'may30monas3cureAndRand0m123!' # Used to secure session data
DATABASE = 'app.db' # Path to SQLite database


def get_db():
    if 'db' not in g:
        g.db = sqlite3.connect(DATABASE)
        g.db.row_factory = sqlite3.Row  # Makes rows behave like dictionaries
    return g.db

# Close the database connection after each request
@app.teardown_appcontext
def close_db(exception):
    db = g.pop('db', None)
    if db:
        db.close()

# Home route: redirect to dashboard if logged in, otherwise to login
@app.route('/')
def home():
    if 'username' in session:
        return redirect(url_for('dashboard'))
    return redirect(url_for('login'))

# Login route: handles user authentication
@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']

        db = get_db()
        user = db.execute("SELECT * FROM users WHERE username = ?", (username,)).fetchone()

        if user and check_password_hash(user['password'], password):
            session['username'] = user['username']
            session['role'] = user['role']
            session['user_id'] = user['id']
            return redirect(url_for('admin' if user['role'] == 'admin' else 'dashboard'))
        else:
            flash('Invalid username or password')
    return render_template('login.html')

# Registration route: creates a new user
@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        confirm = request.form['Confirm-Password']

        if password != confirm:
            flash('Passwords do not match.')
            return redirect(url_for('register'))

        db = get_db()
        try:
            # Hash password and store user in the database
            db.execute(
                "INSERT INTO users (username, password) VALUES (?, ?)",
                (username, generate_password_hash(password))
            )
            db.commit()
            flash('Registration successful. Please log in.')
            return redirect(url_for('login'))
        except sqlite3.IntegrityError:
            flash('Username already taken.')
            return redirect(url_for('register'))

    return render_template('register.html')

# Logout route: clears session data
@app.route('/logout')
def logout():
    session.clear()
    return redirect(url_for('login'))

# Dashboard route: lets users view and post comments
@app.route('/dashboard', methods=['GET', 'POST'])
def dashboard():
    if 'username' not in session:
        flash('Please log in to access the dashboard.')
        return redirect(url_for('login'))

    db = get_db()
    user_id = session['user_id']

    if request.method == 'POST':
        comment = request.form.get('comment')
        if comment:
            db.execute("INSERT INTO comments (user_id, content) VALUES (?, ?)", (user_id, comment))
            db.commit()

    # Fetch all comments for the logged-in user
    comments = db.execute("SELECT content FROM comments WHERE user_id = ?", (user_id,)).fetchall()

    return render_template('dashboard.html', username=session['username'], comments=comments)

# Admin route: restrict access to admin users only
@app.route('/admin')
def admin():
    if 'username' not in session or session.get('role') != 'admin':
        return "Access Denied: Admins only"
    return render_template('admin.html', username=session['username'])

# -------- Run the App --------
if __name__ == '__main__':
    app.run(debug=True, ssl_context=('cert.pem', 'key.pem'))  # Runs with HTTPS (cert + key required)
