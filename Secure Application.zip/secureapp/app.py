from flask import Flask, render_template, request, redirect, url_for, session, flash 
from werkzeug.security import generate_password_hash, check_password_hash 

app = Flask(__name__)
app.secret_key = 'may30monas3cureAndRand0m123!' # Secret key for session management

# In-memory storage for user data and comments
user_db = {}
comments = []

# Pre-defined admin user
user_db['admin'] = {
    'password': generate_password_hash('admin123'),  # Set admin password
    'role': 'admin',
    'comments': []
}


# Home route: redirects logged-in users to dashboard, otherwise to login
@app.route('/')
def home():
    if 'username' in session:
        return render_template('dashboard.html', username=session['username'])
    else:
        return redirect(url_for('login'))
    

# Login route: handles both login form display and authentication logic
@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')

        user = user_db.get(username)

        if user and check_password_hash(user['password'], password):
            session['username'] = username
            session['role'] = user.get('role', 'user')  # Default to 'user'
            session['user_id'] = username  # Dummy ID

            # Redirect admin to /admin, others to /dashboard
            if session['role'] == 'admin':
                return redirect(url_for('admin'))
            else:
                return redirect(url_for('dashboard'))
        else:
            flash('Invalid username or password')

    return render_template('login.html')



# Registration route: creates a new user with hashed password
@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        confirm = request.form['Confirm-Password']

        if username in user_db:
            flash('Username already taken.')
            return redirect(url_for('register'))

        if password != confirm:
            flash('Passwords do not match.')
            return redirect(url_for('register'))

        # Store user with hashed password
        hashed_pw = generate_password_hash(password)
        user_db[username] = {
    'password': hashed_pw,
    'role': 'user',
    'comments': []
}

        
        # Print the user_db to check the hashed password
        print(user_db)  

        flash('Registration successful. Please log in.')
        return redirect(url_for('login'))

    return render_template('register.html')

# Logout route: clears the session and redirects to login
@app.route('/logout')
def logout():
    session.pop('username', None)
    return redirect(url_for('login'))


# Dashboard route: allows logged-in users to view and submit comments
@app.route('/dashboard', methods=['GET', 'POST'])
def dashboard():
    if 'username' not in session:
        flash('Please log in to access the dashboard.')
        return redirect(url_for('login'))

    username = session['username']
    user = user_db.get(username)

    if request.method == 'POST':
        comment_text = request.form.get('comment')
        if comment_text:
            user['comments'].append({
                'user': username,
                'content': comment_text
            })

    return render_template('dashboard.html', username=username, comments=user['comments'])

# Admin-only route: restricts access to users with 'admin' role
@app.route('/admin')
def admin():
    # If user is not logged in, show access denied instead of redirecting
    if 'username' not in session or session.get('role') != 'admin':
        return "Access Denied: Admins only"

    return render_template('admin.html', username=session['username'])




# Run the app with SSL enabled (requires cert.pem and key.pem files)
if __name__ == '__main__':
  app.run(debug=True, ssl_context=('cert.pem', 'key.pem'))