from flask import Flask, render_template, redirect, url_for, request, flash, session
import sqlite3
import os

app = Flask(__name__)
app.secret_key = 'insecure_key'  # Hardcoded insecure secret key (used for sessions)
DATABASE = 'vuln.db'

# Database connection function
def get_db():
    conn = sqlite3.connect(DATABASE)
    conn.row_factory = sqlite3.Row
    return conn

# Create tables and insert a test user if none exist
with app.app_context():
    conn = get_db()
    conn.execute('''CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT UNIQUE NOT NULL,
        password TEXT NOT NULL,
        role TEXT DEFAULT 'user'
    )''')
    conn.execute('''CREATE TABLE IF NOT EXISTS comments (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        content TEXT NOT NULL,
        user TEXT NOT NULL
    )''')
    result = conn.execute("SELECT COUNT(*) FROM users").fetchone()
    if result[0] == 0:
        # Default test user with plaintext password (no hashing)
        conn.execute("INSERT INTO users (username, password, role) VALUES (?, ?, ?)", ('test', 'test', 'user'))
    conn.commit()
    conn.close()

# Redirect root URL to login page
@app.route('/')
def home():
    return redirect(url_for('login'))

# User Registration Route
@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']  # Password is stored in plaintext (security flaw)
        conn = get_db()
        try:
            print("Trying to register:", username)
            conn.execute("INSERT INTO users (username, password) VALUES (?, ?)", (username, password))
            conn.commit()
            flash('Registered (insecurely)', 'success')
            return redirect(url_for('login'))
        except:
            flash('Username already exists', 'danger')
        finally:
            conn.close()
    return render_template('register.html')

# User Login Route
@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        conn = get_db()
        # Vulnerable to SQL Injection: user input is directly inserted into query string
        query = f"SELECT * FROM users WHERE username = '{username}' AND password = '{password}'"
        result = conn.execute(query).fetchone()
        conn.close()
        if result:
            session['user'] = result['username']
            session['role'] = result['role']
            flash('Logged in (insecurely)', 'success')
            return redirect(url_for('dashboard'))
        else:
            flash('Invalid credentials', 'danger')
    return render_template('login.html')

# Dashboard Page
@app.route('/dashboard', methods=['GET', 'POST'])
def dashboard():
    if 'user' not in session:
        return redirect(url_for('login'))

    conn = get_db()
    if request.method == 'POST':
        comment = request.form['comment']
        # No input sanitization — vulnerable to XSS
        conn.execute("INSERT INTO comments (content, user) VALUES (?, ?)", (comment, session['user']))
        conn.commit()

    comments = conn.execute("SELECT * FROM comments ORDER BY id DESC").fetchall()
    conn.close()
    return render_template('dashboard.html', user=session['user'], comments=comments)

# No access control — any logged-in user (or even without login) can access this route
@app.route('/admin')
def admin():
    return "Welcome to the admin panel! Anyone can access this."

# Logout route — clears session
@app.route('/logout')
def logout():
    session.clear()
    return redirect(url_for('login'))

# Run the app in debug mode (not recommended for production)
if __name__ == '__main__':
    app.run(debug=True)
